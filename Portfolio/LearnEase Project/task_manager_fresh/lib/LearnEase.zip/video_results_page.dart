import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'services/task_sorting.dart';

class VideoResultsPage extends StatefulWidget {
  final String query;
  const VideoResultsPage({Key? key, required this.query}) : super(key: key);

  @override
  _VideoResultsPageState createState() => _VideoResultsPageState();
}

class _VideoResultsPageState extends State<VideoResultsPage> {
  late Future<List<Map<String, String>>> _futureResults;
  final TaskSortingService _sortingService = TaskSortingService();

  @override
  void initState() {
    super.initState();
    _futureResults = _loadResources();               // ← runs once per page
  }

  /// Fetches 3 website links + 3 YouTube links **in parallel**.
  Future<List<Map<String, String>>> _loadResources() async {
    final futures = await Future.wait([
      _sortingService.getWebsiteRecommendations(widget.query),
      _sortingService.getYouTubeRecommendations(widget.query),
    ]);

    final webLinks = futures[0].take(3).toList();
    final ytLinks  = futures[1].take(3).toList();

    final results = <Map<String, String>>[];

    // website items
    for (final url in webLinks) {
      results.add({
        'type' : 'web',
        'url'  : url,
        'title': url,          // could add a prettier title later
      });
    }

    // YouTube items (use existing meta helper for thumbnails/titles)
    for (final url in ytLinks) {
      final meta = await _sortingService.getYouTubeMeta(url);
      results.add({
        'type' : 'video',
        'url'  : url,
        'title': meta['title'] ?? url,
        'thumb': meta['thumb'] ?? '',
      });
    }

    return results;
  }

  Widget _buildItem(Map<String, String> item) {
    if (item['type'] == 'web') {
      return ListTile(
        leading: const Icon(Icons.language),
        title: Text(item['title']!,
            maxLines: 2, overflow: TextOverflow.ellipsis),
        subtitle: const Text('Website'),
        onTap: () => launchUrl(Uri.parse(item['url']!)),
      );
    }

    // YouTube tile
    return ListTile(
      leading: item['thumb']?.isNotEmpty == true
          ? Image.network(item['thumb']!,
          width: 64, height: 64, fit: BoxFit.cover)
          : const Icon(Icons.play_circle_fill, size: 64),
      title: Text(item['title']!,
          maxLines: 2, overflow: TextOverflow.ellipsis),
      subtitle: const Text('YouTube'),
      onTap: () => launchUrl(Uri.parse(item['url']!)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Resources for "${widget.query}"')),
      body: FutureBuilder<List<Map<String, String>>>(
        future: _futureResults,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return const Center(child: Text('No results found.'));
          }
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) => _buildItem(items[index]),
          );
        },
      ),
    );
  }
}

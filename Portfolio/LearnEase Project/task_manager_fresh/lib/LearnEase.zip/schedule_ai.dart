import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'task_sorting.dart';

class ScheduleAI {
  final TaskSortingService _svc;
  final Iterable<DateTime> _blueDates;

  ScheduleAI(this._svc, this._blueDates);

  Future<List<Map<String, dynamic>>> getSuggestedSchedule(
      String task,
      DateTime due,
      String difficulty,
      List<Map<String, dynamic>> existingTasks,
      List<Map<String, dynamic>> classRecords,
      ) async {
    final now = DateTime.now();
    final formattedDue = DateFormat('yyyy-MM-dd').format(due);

    // -------------------------------- existing blocks text -------------
    final existingBlocks = existingTasks
        .where((t) => t['sessions'] != null)
        .expand((t) => (t['sessions'] as List).map((s) {
      final startIso = (s['start'] as DateTime).toIso8601String();
      final endIso   = (s['end']   as DateTime).toIso8601String();
      return '${t['task']}: $startIso to $endIso';
    }))
        .join('\n');

    // ------------------------------- PROMPT (only part we changed) -----
    final prompt = '''
Today is ${DateFormat('yyyy-MM-dd').format(now)}.

You are helping a student create an efficient, balanced study-schedule.

📝 Task: "$task"   (difficulty: $difficulty)  
📅 Due date: $formattedDue

They already have these fixed blocks:
$existingBlocks

⚠️  **Hard rules**  
1. All suggested blocks must be **today or later** — never before “Today”.  
2. All blocks must end **on or before the due date**.  
3. Do not overlap any block listed above.

🤖 **Guidelines**  
• If the due date is more than 2 full days away **and** the task is Medium or Hard, split work into **at least 2 sessions**.  
• Hard ⇒ 60- to 90-minute sessions (split if needed).  
• Medium ⇒ 45- to 60-minute sessions.  
• Easy ⇒ one 30- to 45-minute session.  
• Leave sensible breaks between sessions.

📝 **Respond with JSON only** – an array like:

[
  { "start": "2025-05-11T14:00:00", "end": "2025-05-11T15:00:00" }
]

No markdown, no comments.
''';
    // -------------------------------------------------------------------

    final raw = await _svc.simplePrompt(prompt);
    final cleaned = raw.trim().replaceAll('```json', '').replaceAll('```', '');

    // Allow same-day scheduling only if due is today
    final todayMid = DateTime(now.year, now.month, now.day);
    final dueMid   = DateTime(due.year, due.month, due.day);
    final allowSameDay = todayMid == dueMid;

    List<Map<String, dynamic>> suggestions;
    try {
      final decoded = jsonDecode(cleaned) as List<dynamic>;
      suggestions = decoded.cast<Map<String, dynamic>>().where((blk) {
        final start = DateTime.parse(blk['start']);
        final end   = DateTime.parse(blk['end']);

        // rule: today or later, but not after due
        if (!allowSameDay && !start.isBefore(dueMid)) return false;
        // conflict check
        return !_conflictsWithClass(start, end, classRecords);
      }).map((blk) {
        return {
          'start': blk['start'],
          'end'  : blk['end'],
          'title': '${_generateTitlePrefix(task)} ${task.trim()}',
        };
      }).toList();
    } catch (e) {
      print('❌ Failed to parse AI schedule: $e');
      suggestions = [];
    }

    if (suggestions.isNotEmpty) return suggestions;

    // ---------------- fallback: one-hour block 9 AM day before due ------
    final fbDay = due.subtract(const Duration(days: 1));
    final s = DateTime(fbDay.year, fbDay.month, fbDay.day, 9);
    final e = s.add(const Duration(hours: 1));
    return [
      {
        'start': s.toIso8601String(),
        'end'  : e.toIso8601String(),
        'title': '${_generateTitlePrefix(task)} ${task.trim()}',
      }
    ];
  }

  // --------------------- helper: dynamic title prefix ------------------
  String _generateTitlePrefix(String task) {
    final t = task.toLowerCase();
    if (t.contains('quiz') || t.contains('exam') || t.contains('test')) {
      return 'Study';
    } else if (t.contains('assignment') ||
        t.contains('paper') ||
        t.contains('project')) {
      return 'Work on';
    } else if (t.contains('read') ||
        t.contains('chapter') ||
        t.contains('book')) {
      return 'Read';
    } else if (t.contains('write') || t.contains('essay')) {
      return 'Write';
    } else if (t.contains('present') || t.contains('presentation')) {
      return 'Prepare';
    } else {
      return 'Do';
    }
  }

  // --------------------- helper: class conflict check ------------------
  bool _conflictsWithClass(
      DateTime start, DateTime end, List<Map<String, dynamic>> classRecords) {
    final dayName = DateFormat('EEEE').format(start);
    for (final c in classRecords) {
      if (c['day'] != dayName) continue;
      final classStart =
      TimeOfDay(hour: c['start'].hour, minute: c['start'].minute);
      final classEnd =
      TimeOfDay(hour: c['end'].hour, minute: c['end'].minute);
      final bStart = TimeOfDay(hour: start.hour, minute: start.minute);
      final bEnd = TimeOfDay(hour: end.hour, minute: end.minute);

      final overlap = !(bEnd.hour < classStart.hour ||
          (bEnd.hour == classStart.hour && bEnd.minute <= classStart.minute) ||
          bStart.hour > classEnd.hour ||
          (bStart.hour == classEnd.hour && bStart.minute >= classEnd.minute));

      if (overlap) return true;
    }
    return false;
  }

    // 1) Clear old sessions
    for (final t in tasks) t['sessions'] = <Map<String, dynamic>>[];

    // 2) Sort by difficulty, then by nearest due date
    const weight = {'Hard': 0, 'Medium': 1, 'Easy': 2};
    tasks.sort((a, b) {
      final w = weight[(a['difficulty'] ?? 'Medium')]!
          .compareTo(weight[(b['difficulty'] ?? 'Medium')]!);
      return w != 0
          ? w
          : DateTime.parse(a['date']).compareTo(DateTime.parse(b['date']));
    });

    // 3) Rebuild sessions for each task using the EXISTING public API
    for (final t in tasks) {
      final blocks = await ScheduleAI.getSuggestedSchedule(
      t['task'],
        DateTime.parse(t['date']),
        t['difficulty'],
        tasks,          // pass the full list for conflict awareness
        classRecords,
      );

      if (blocks.isNotEmpty) {
        t['sessions'] = blocks.map((b) => {
          'start': DateTime.parse(b['start']),
          'end'  : DateTime.parse(b['end']),
          'title': b['title'] as String,
        }).toList();
      }
    }
    return tasks;
  }

}

